<?php
defined('BASEPATH') OR exit('No direct script access allowed');
header("Access-Control-Allow-Origin: *");
class Api extends CI_Controller {

     function __construct() {
        parent::__construct();
       $this->load->model('all');
    }
	
	public function product(){
		$data['status']='success';
		$data['productList']=$this->all->getData('product');
		echo json_encode($data);
	}
}
