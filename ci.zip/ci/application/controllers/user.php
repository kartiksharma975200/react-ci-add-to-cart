<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

    function _construct(){
    	 parent::__construct();
        
    }
	public function index()
	{
		if($this->session->userdata('user_id')){
           redirect('dashboard');
         }
		$this->load->view('user/login');
		
	}
	public function login()
	{
		$this->form_validation->set_rules('username', 'Username', 'required');
		$this->form_validation->set_rules('Password', 'Password', 'required');
		if ($this->form_validation->run() == FALSE)
            {  $this->load->view('user/login');}
            else{   $this->load->model('all');
            if($res=$this->all->login($_POST)){
                $this->session->set_userdata('user_id',$res[0]->id);
                redirect('dashboard');
            }else{
                 $this->session->set_flashdata('message', "Login Details don't match");
                 $this->load->view('user/login');
            }
        }
    }
	
}
