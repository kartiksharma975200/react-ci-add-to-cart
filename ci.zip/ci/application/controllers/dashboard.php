<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

     function __construct() {
        parent::__construct();
        if(!$this->session->userdata('user_id')){
           redirect('user');
        }
        $this->load->model('all');
    }
	public function index()
	{
		$this->load->view('user/header');
		$this->load->view('user/home');
		$this->load->view('user/footer');
	}
	public function add(){
		$this->load->view('user/header');
		$this->load->view('user/product_add');
		$this->load->view('user/footer');
	}

	public function saveProduct(){
		$this->form_validation->set_rules('title', 'Title', 'required');
		$this->form_validation->set_rules('price', 'Price', 'required|numeric');
		$this->form_validation->set_rules('details', 'details', 'required');
		 if ($this->form_validation->run() == FALSE)
            {  
            	$this->load->view('user/header');
				$this->load->view('user/product_add');
				$this->load->view('user/footer');
            }
            else{  
            	$config['upload_path']          = './assets/image';
                $config['allowed_types']        = 'gif|jpg|png';
                $config['max_size']             = 100;
                $config['max_width']            = 1024;
                $config['max_height']           = 768;
                $this->load->library('upload', $config);

                if ( ! $this->upload->do_upload('image'))
                {       
                        $this->session->set_flashdata('message', "Image Uplaod faild somthing was wrong");
                        $this->load->view('user/header');
						$this->load->view('user/product_add');
						$this->load->view('user/footer');
                }
                else
                {
                        $data = array('image' => $this->upload->data());
                        $imageName=$data['image']['file_name'];
                        $formdata = array('image' => $imageName,'title'=>$_POST['title'],'details'=>$_POST['details'],'price'=>$_POST['price']);
                                  $this->load->model('all');
                        if($this->all->insertData('product',$formdata)){
                        	$this->session->set_flashdata('message', "Form submit success ");
                           redirect('Dashboard/add');
                        }else{
                        	$this->load->view('user/header');
							$this->load->view('user/product_add');
							$this->load->view('user/footer');
                        	$this->session->set_flashdata('message', "Form submit fail please try again");
                        }
                }
               
              
             }
	}
	public function edit($id=null){
		$where = array('id' =>$id);
		$data['product']=$this->all->getDataCondition('product',$where);
		$this->load->view('user/header');
		$this->load->view('user/product_edit',$data);
		$this->load->view('user/footer');
	}
	public function editProduct($id=null){
		$this->form_validation->set_rules('title', 'Title', 'required');
		$this->form_validation->set_rules('price', 'Price', 'required|numeric');
		$this->form_validation->set_rules('details', 'details', 'required');
		 if ($this->form_validation->run() == FALSE)
            {  
            	$this->load->view('user/header');
				$this->load->view('user/product_add');
				$this->load->view('user/footer');
            }
            else{  
            	$config['upload_path']          = './assets/image';
                $config['allowed_types']        = 'gif|jpg|png';
                $config['max_size']             = 100;
                $config['max_width']            = 1024;
                $config['max_height']           = 768;
                $this->load->library('upload', $config);
                $imageName='';
                if($_File['image']['name']!=''){
              			 if ( ! $this->upload->do_upload('image'))
		                {       
		                        $this->session->set_flashdata('message', "Image Uplaod faild somthing was wrong");
		                        $this->load->view('user/header');
								$this->load->view('user/product_edit');
								$this->load->view('user/footer');
		                }
		                else
		                {
		                        $data = array('image' => $this->upload->data());
		                        $imageName=$data['image']['file_name'];
		                        
		                }
                }else{
                	$imageName=$_POST['old_image'];
                }
                $where = array('id' =>$id);
                $formdata = array('image' => $imageName,'title'=>$_POST['title'],'details'=>$_POST['details'],'price'=>$_POST['price']);
		          if($this->all->updateData('product',$formdata,$where)){
		             $this->session->set_flashdata('message', "Form submit success ");
		                 redirect('Dashboard/view');
		            }else{
		               $this->load->view('user/header');
							$this->load->view('user/product_edit');
							$this->load->view('user/footer');
		                    $this->session->set_flashdata('message', "Form submit fail please try again");
		            }
                }
	}
	public function view(){
		$data['productData']=$this->all->getData('product');
		$this->load->view('user/header');
		$this->load->view('user/product_view',$data);
		$this->load->view('user/footer');
	}
}
