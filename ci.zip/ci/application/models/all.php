<?php 
class All extends CI_Model {
	function login($post){
            $this->db->select('*');
			$this->db->from('user');
			$where = array('name' =>$post['username'] , 'pass'=>$post['Password'] );
		    $this->db->where($where);
			$query = $this->db->get();
			if ($query->num_rows() == 1) {
				return $query->result();
				} else {
				return false;
				}
	}
	function insertData($table,$data){
       if($this->db->insert($table,$data)){
       	 return true;
       }else{
       	return false;
       }
	}
	function getData($table){
		$this->db->select('*');
		$this->db->from($table);
		$query=$this->db->get();
		return $query->result();
	}
	function getDataCondition($table,$condition){
		$this->db->select('*');
		$this->db->from($table);
		$this->db->where($condition);
		$query=$this->db->get();
		return $query->result();
	}
	function updateData($table,$data,$condition){
       $this->db->where($condition);
       $this->db->update($table,$data);
       return true;
	}
}
?>