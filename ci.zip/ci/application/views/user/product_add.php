<div class="container"> 
  <div class="row"> 
  	<div class="col-md-6 col-md-offset-3">
  		<div class="row">
  			<div class="form-group">
          <?php echo validation_errors(); ?>
         
          <?php if($this->session->flashdata('message')){
            ?>
            <a class="alert alert-danger" style="margin-top:50px;"><?php echo $this->session->flashdata('message'); ?></a>
            <?php

          } ?>
  				<form method="post" enctype="multipart/form-data" action="<?php echo base_url(); ?>/dashboard/saveProduct" style="margin-top:50px;">
  					<label>Product name</label>
  					<input type="text" name="title" value="<?php echo set_value('title'); ?>" class="form-control">
  					<label>Price</label>
  					<input type="number" name="price" value="<?php echo set_value('price'); ?>" class="form-control">
            <label>Details</label>
            <textarea class="form-control" name="details">
              <?php echo set_value('details'); ?>
            </textarea>
            <label>Image</label>
            <input type="file" name="image" class="form-control" value="<?php echo set_value('image'); ?>">
  					<hr>
  					<input type="submit" name="subit" value="Login" class="btn btn-info">
  				</form>
  			</div>
  		</div>
  	</div>
  </div>
</div>