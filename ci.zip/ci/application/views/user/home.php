<div class="container">
  <h3>User Data</h3>
  <div class="row">
  	 <div class="col-md-12">
  	 	<table class="table table-bordered">
  	 		<thead>
  	 			<tr>
  	 				<th>Id</th>
  	 				<th>Image</th>
  	 				<th>Title</th>
  	 				<th>Price</th>
  	 				<th>Action</th>
  	 			</tr>
  	 		</thead>
  	 		<tbody>
  	 			<tr>
  	 				<td>hello</td>
  	 				<td>hello</td>
  	 				<td>hello</td>
  	 				<td>hello</td>
  	 				<td>hello</td>
  	 			</tr>
  	 		</tbody>
  	 	</table>
  	 </div>
  </div>
</div>