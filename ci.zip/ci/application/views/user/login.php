<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container"> 
  <div class="row"> 
  	<div class="col-md-6 col-md-offset-3">
  		<div class="row">
  			<div class="form-group">
          <?php echo validation_errors(); ?>
          <?php if($this->session->flashdata('message')){
            ?>
            <a class="alert alert-danger" style="margin-top:50px;"><?php echo $this->session->flashdata('message'); ?></a>
            <?php

          } ?>
  				<form method="post" action="<?php echo base_url(); ?>/user/login" style="margin-top:50px;">
  					<label>User Name</label>
  					<input type="text" name="username" value="<?php echo set_value('username'); ?>" class="form-control">
  					<label>Password</label>
  					<input type="Password" name="Password" value="<?php echo set_value('Password'); ?>" class="form-control">
  					<hr>
  					<input type="submit" name="subit" value="Login" class="btn btn-info">
  				</form>
  			</div>
  		</div>
  	</div>
  </div>
</div>



</body>
</html>