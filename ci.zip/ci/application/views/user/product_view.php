<div class="container">
  <h3>Product List</h3>
  <div class="row">
  	 <div class="col-md-12">
  	 	<table class="table table-bordered">
  	 		<thead>
  	 			<tr>
  	 				<th>Id</th>
  	 				<th>Image</th>
  	 				<th>Title</th>
  	 				<th>Price</th>
  	 				<th>Action</th>
  	 			</tr>
  	 		</thead>
  	 		<tbody>
          <?php if(!empty($productData)){
            foreach ($productData as $key) {
             
            ?>
  	 			<tr>
  	 				<td><?php echo $key->id; ?></td>
  	 				<td><img src="<?php echo 'http://localhost/ci/assets/image/'. $key->image; ?>" style="width:100px"></td>
  	 				<td><?php echo $key->title; ?></td>
  	 				<td><?php echo $key->price; ?> Rs</td>
  	 				<td><a class="btn btn-info" href="<?php echo base_url() ?>/dashboard/edit/<?php echo $key->id; ?>" >Edit</a><a class="btn btn-info" >Delete</a></td>
  	 			</tr>
        <?php } } else{
         ?><tr><td colspan="5">No data in record</td></tr><?php
        }?>
  	 		</tbody>
  	 	</table>
  	 </div>
  </div>
</div>
