import React , { Component } from 'react';
import Header from '../component/header';

class Cart extends Component {

     constructor(props){
         super(props);
         this.state={
             cartList:JSON.parse(localStorage.getItem('cartList')),
         }
     }
     componentWillMount(){
       if(localStorage.getItem('cartList')){
            var  cartList=JSON.parse(localStorage.getItem('prodcartListuctList')); 
         }
     }
     componentDidMount(){
        if(localStorage.getItem('cartList')){
             var  cartList=JSON.parse(localStorage.getItem('cartList')); 
          }
      }
     render(){
         return(
             <div>
                 <Header />
                 <ul>
                 {
                     this.state.cartList && this.state.cartList.length>0 ?
                        this.state.cartList.map((cart,i)=>(
                            <li key={i}>{cart.name}</li>
                        ))
                     :<li>no data</li>
                 }
                
             </ul>
             </div>
             
         )
     }
}
export default Cart;