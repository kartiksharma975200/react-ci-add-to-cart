import React, { Component } from 'react';
import Header from '../component/header';
class Addproduct extends Component {
    constructor(props) {
        super(props);
        this.state = {
            name: '',
            details: '',
            price: '',
            errorList: '',

        }
        this.changeForm = this.changeForm.bind(this);
        this.formSubmit = this.formSubmit.bind(this);
    }
    changeForm(event) {
        var tarName = event.target.name;
        this.setState({ [tarName]: event.target.value })
    }
    formSubmit(e) {
        e.preventDefault();
        var errorList = [];
        var name = this.state.name;
        var details = this.state.details;
        var price = this.state.price;
        if (name === '' || !name.length > 0) {
            errorList.push("Name field is required");
        }
        if (details === '' || !details.length > 0) {
            errorList.push("details field is required");
        }
        if (price === '' || !price.length > 0) {
            errorList.push("price field is required");
        }
        this.setState({ errorList });
        if (errorList > 0) {

        } else {
            if (this.state.price.length > 0 && this.state.name.length > 0 && this.state.details.length > 0) {
                var ProductListArray = JSON.parse(localStorage.getItem('productList'));
                const formData = {
                    'name': this.state.name,
                    'details': this.state.details,
                    'price': this.state.price
                }
                ProductListArray.push(formData);
                this.setState({ name: '' });
                this.setState({ details: '' });
                this.setState({ price: '' });
                document.getElementById("myForm").reset();
                localStorage.setItem('productList', JSON.stringify(ProductListArray));
            }

        }

    }
    render() {

        return (
            <div>
                <Header />
                <div className="container">
                    <div className="col-md-6 col-md-offset-3">
                        <div className="form-group well">
                            <h2>Add Product</h2>
                            {this.state.errorList.length > 0 ?
                                this.state.errorList.map((err, i) => (
                                    <p className="text text-danger">{err}</p>
                                ))
                                : ''}
                            <form onSubmit={this.formSubmit} id="myForm">
                                <label>Product Name</label>
                                <input type="text" onChange={this.changeForm} name="name" className="form-control" />
                                <label>Product Details</label>
                                <textarea className="form-control" onChange={this.changeForm} name="details"></textarea>
                                <label>Product Price</label>
                                <input type="number" className="form-control" onChange={this.changeForm} name="price" />
                                <hr />
                                <input type='submit' className="btn btn-info" value='Submit' />
                            </form>
                        </div>
                    </div>

                </div>
            </div>

        )
    }
}
export default Addproduct;