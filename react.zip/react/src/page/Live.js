import React ,{Component} from 'react';
import Header from '../component/header';
import axios from 'axios';

class Live extends Component {
   
    constructor(props){
        super(props);
        this.state={
            message:'welcome in live data',
            product:'',
        }
    }
    componentDidMount(){
        axios.get('http://localhost/ci/index.php/Api/product')
            .then(res=>(
                this.setState({product:res})
            ))
            .catch(function (error) {
                console.log(error);
            });
    }
     
    render(){
        return(
            <div>
                <Header /> 
                {this.state.message}
                <table className="table table-bordered">
                   <thead>
                       <tr>
                           <th>Id</th>
                           <th>Name</th>
                           <th>Image</th>
                           <th>Price</th>
                           <th>Action</th>
                       </tr>
                   </thead>
                   <tbody>
                       {this.state.product && this.state.product && this.state.product.data.productList ? 
                       this.state.product.data.productList.map((pro,i)=>(
                        <tr>
                            <td>{pro.id}</td>
                            <td>{pro.title}</td>
                            <td><img src={"http://localhost/ci/assets/image/"+pro.image} style={{'width':'100px'}} /></td>
                            <td>{pro.price} . Rs</td>
                            <td></td>
                        </tr>
                       ))
                       
                        
                        :<tr>
                            <td colSpan="5">No data in table</td>
                        </tr>}
                       
                   </tbody>
                </table>
                <p>{this.state.message}</p>
            </div>
            
        )
    }
}
export default Live