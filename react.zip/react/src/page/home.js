import React, { Component } from 'react';


import Header from '../component/header';
class Home extends Component {
    constructor(props){
        super(props);
        this.state={
            productList:JSON.parse(localStorage.getItem('productList')),
            totalCost:localStorage.getItem('totalCost'),
            totalProduct:localStorage.getItem('totalProduct'),
        }
    }
    addProductInCart(product){
        if(localStorage.getItem('cartList')){
            var cartList=JSON.parse(localStorage.getItem('cartList'));
            const formData = {
                'name': product.name,
                'details': product.details,
                'price': product.price
            }
            cartList.push(formData);
            localStorage.setItem('cartList', JSON.stringify(cartList));
        }else{
            var testObject = [{name:product.name, details:product.details,price:product.price}];
            localStorage.setItem('cartList', JSON.stringify(testObject));
        }

        var totalCost=parseInt(this.state.totalCost) + parseInt(product.price);
        this.setState({totalCost});
        var totalProduct=parseInt(this.state.totalProduct) + 1;
        this.setState({totalProduct});
        localStorage.setItem('totalCost',totalCost);
        localStorage.setItem('totalProduct',totalProduct);
    }
    render() {
        return (
            <div>
                <Header / >
                <div className="container">

                <h2>Welcome in react </h2>
                <div className="panel panel-default">
                    <div className="panel-heading">Product List</div>
                    <div className="panel-body">
                      <p>Total Product : {this.state.totalProduct}</p>
                      <p>Total Cost : {this.state.totalCost}</p>
                      <table className="table table-bordered">
                          <thead>
                              <tr>
                                  <td>Name</td>
                                  <td>Details</td>
                                  <td>Price</td>
                                  <td>Add To Cart</td>
                              </tr>
                          </thead>
                          <tbody>
                              {this.state.productList && this.state.productList.length>0 ?
                              this.state.productList.map((product,i)=>(
                                <tr key={i}>
                                  <td>{product.name}</td>
                                  <td>{product.details}</td>
                                  <td>{product.price} Rs</td>
                                  <td><a className="btn btn-info" onClick={()=>this.addProductInCart(product)}> Add To Cart</a></td>
                              </tr>
                              ))
                              
                              :
                              <tr>
                                  <td colspan="4">No product available</td>
                              </tr>
                              }
                          </tbody>
                      </table>
                    </div>
                    <div className="panel-footer">Panel Footer</div>
                </div>
             
               
            
            </div>
            </div>
            

        )
    }
}
export default Home;