import React, { Component } from 'react';
import {Link } from 'react-router-dom';
class Header extends Component {

    render() {
        return (
           
            <nav className="navbar navbar-default">
            <div className="container-fluid">
              <div className="navbar-header">
                <a className="navbar-brand" href="#">WebSiteName</a>
              </div>
              <ul className="nav navbar-nav">
                <li><Link to='/'>Home</Link></li>
                <li><Link to='/about'>About</Link></li>
                <li><Link to='/liveList'>Live Product List</Link></li>
                <li><Link to='/add-product'>Add Product</Link></li>
                <li><Link to='/cart'>Cart List</Link></li>
              </ul>
            </div>
          </nav>
           
        )
    }
}
export default Header;