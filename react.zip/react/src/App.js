import React, { Component } from 'react';

import './App.css';
import Home from './page/home';
import About from './page/about';
import Addproduct from './page/addproduct';
import Cart from './page/cart';
import Live from './page/Live';
import { BrowserRouter, Route, Switch,Link } from 'react-router-dom';

class App extends Component {
  render() {
    return (
      <div className="App">
                
                <BrowserRouter>
                
                    <Switch>
                        <Route exact path='/' component={Home} />
                        <Route path='/about' component={About} />
                        <Route path="/add-product" component={Addproduct} />
                        <Route path="/cart" component={Cart} />
                        <Route path="/liveList" component={Live} />
                    </Switch>
                </BrowserRouter> 
              
      </div>
    );
  }
}

export default App;
